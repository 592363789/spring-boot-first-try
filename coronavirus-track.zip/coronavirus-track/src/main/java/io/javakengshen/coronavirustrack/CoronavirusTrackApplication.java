package io.javakengshen.coronavirustrack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoronavirusTrackApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoronavirusTrackApplication.class, args);
	}

}
